$('[data-toggle=confirmation]').confirmation({
  	rootSelector: '[data-toggle=confirmation]',
	//btnOkLabel: 'Si',
	//btnCancelLabel: 'No'
});
